package com.babbangona.sd2;

import java.io.Serializable;
import java.sql.Date;

/**
 * Created by ciani on 27/03/2018.
 */

public class Transaction implements Serializable{
    private String id;
    private String idonline;
    private String type;
    private String msg;
    private String product;
    private String unit;
    private String quant;
    private String dest;
    private String src;
    private String date;
    private Status status;
    private String sync;

    public enum Status{Started, Collected, Delivered, Cancelled}

    //array adapter constructor
    public Transaction(String id, String idonline, String type, String msg, String product, String unit, String quant, String dest, String src, String date, String status, String sync) {
        this.id = id;
        this.idonline = idonline;
        this.type = type;
        this.msg = msg;
        this.product = product;
        this.unit = unit;
        this.quant = quant;
        this.dest = dest;
        this.src = src;
        this.date = date;
        this.status = Status.valueOf(status);
        this.sync = sync;
    }

    //database constructor
    public Transaction(String idonline, String type, String msg, String product, String unit, String quant, String dest, String src) {
        this.idonline = idonline;
        this.type = type;
        this.msg = msg;
        this.product = product;
        this.unit = unit;
        this.quant = quant;
        this.dest = dest;
        this.src = src;
        this.date = new Date(System.currentTimeMillis()).toString();
        this.status = Status.Started;
        this.sync = "no";
    }

    public String getId() {
        return id;
    }

    public String getIdonline() {
        return idonline;
    }

    public String getType() {
        return type;
    }

    public String getMsg() {
        return msg;
    }

    public String getProduct() {
        return product;
    }

    public String getUnit() {
        return unit;
    }

    public String getQuant() {
        return quant;
    }

    public String getDest() {
        return dest;
    }

    public String getSrc() {
        return src;
    }

    public String getDate() {
        return date;
    }

    public Status getStatus() {
        return status;
    }

    public String getSync() {
        return sync;
    }
}
