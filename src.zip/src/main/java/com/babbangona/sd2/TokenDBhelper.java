package com.babbangona.sd2;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.readystatesoftware.sqliteasset.SQLiteAssetHelper;

/**
 * Created by ciani on 12/04/2018.
 */

public class TokenDBhelper extends SQLiteAssetHelper {

    public TokenDBhelper(Context context) {
        super(context, "tokens.db", null, 1);
    }

    public boolean token1Exists(String transID, String token)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from tokens where transID = '" + transID + "' and sending = '" + token + "'";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        if(c.getCount() < 1){ return false;}


        db.execSQL("update tokens set sending = null where transID = '" + transID + "'" );
        c.close();
        db.close();
        return true;
    }

    public boolean token2Exists(String transID, String token)
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from tokens where transID = '" + transID + "' and receiving = '" + token + "'";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        if(c.getCount() < 1){ return false;}

        db.execSQL("delete from tokens where transID = '" + transID + "'");
        c.close();
        db.close();
        return true;
    }

}
