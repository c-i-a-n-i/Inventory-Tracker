package com.babbangona.sd2;

import android.app.Fragment;
import android.app.FragmentManager;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class NewTransaction extends AppCompatActivity {
    Button btnPaste;
    ClipboardManager clipboard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_transaction);

        btnPaste = findViewById(R.id.btnPaste);
        clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);

        if (!(clipboard.hasPrimaryClip())) {
            btnPaste.setEnabled(false);
        } else if (!(clipboard.getPrimaryClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN))) {
            btnPaste.setEnabled(false);
        } else {
            btnPaste.setEnabled(true);
        }
    }

    public void paste_onClick(View v) {
        try {
            ClipData.Item item = clipboard.getPrimaryClip().getItemAt(0);
            //We get the character sequence from the phone's clipboard.

            CharSequence one = "";
            one = item.getText();
            String msg = one.toString(); //We convert the character sequence to a string.

            String[] separated = msg.split(",");
            String type = separated[0].toUpperCase();
            String id = separated[1];
            String src = separated[2];
            String dest = separated[3];
            String product = separated[4];
            String qty = separated[5];
            String unit = separated[6];
            //perform dynamic loading of the frags here
            FragmentManager fragmentManager = getFragmentManager();
            Fragment frag = new InternalTransfer();

            Bundle data = new Bundle();
            data.putString("id", id);
            data.putString("type", type);
            data.putString("src", src);
            data.putString("dest", dest);
            data.putString("product", product);
            data.putString("unit", unit);
            data.putString("qty", qty);
            frag.setArguments(data);
            fragmentManager.beginTransaction().replace(R.id.frag_container, frag).commit();

        } catch (ArrayIndexOutOfBoundsException exception) {
            Toast.makeText(getApplicationContext(), "Please try copying the text again", Toast.LENGTH_LONG).show();
        }

    }
}
