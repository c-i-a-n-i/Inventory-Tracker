package com.babbangona.sd2;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by ciani on 27/03/2018.
 */

public class TransAdapter extends RecyclerView.Adapter<TransAdapter.VH> {
    final ArrayList<Transaction> trans; //holds the list of all transactions in database as transaction objects, declared final because it is used in an inner class
    private final OnItemClickListener listener; //this is the listener that is set on view click, declared final because  "                  "                  "
    Context context;    //this is used to store the context where the adapter will be used.

    //Constructor initializes all of the above, notice it is the same as the normal constructor except now listener is added
    public TransAdapter(Context context, ArrayList<Transaction> trans, OnItemClickListener listener) {
        this.trans = trans;
        this.context = context;
        this.listener = listener;
    }

    //Gets the view holder i.e the layout to hold each transaction view
    @Override
    public TransAdapter.VH onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.trans_row, parent, false);
        return new VH(v);       //returns the view holder class below with the textviews assigned to ids
    }

    @Override
    public void onBindViewHolder(TransAdapter.VH holder, int position) {
        Transaction trans = this.trans.get(position);   //gets current transaction object from array

        holder.tvMsg.setText(trans.getMsg());
        holder.tvTransID.setText("Shipment " + trans.getId());
        holder.tvStatus.setText(trans.getStatus().name());
        holder.tvDate.setText(trans.getDate());
        holder.tvType.setText(trans.getType());

        if (trans.getSync().equals("yes")) {
            holder.imgSyncStatus.setImageResource(R.drawable.ic_done_black_18dp);
        } else {
            holder.imgSyncStatus.setImageResource(R.drawable.ic_update_black_18dp);
        }

        switch (trans.getStatus()) {
            case Cancelled:
                holder.tvStatus.setTextColor(Color.parseColor("#d84315"));
                break;
            case Collected:
                holder.tvStatus.setTextColor(Color.parseColor("#0097a7"));
                break;
            case Started:
                holder.tvStatus.setTextColor(Color.parseColor("#ff5722"));
                break;
            case Delivered:
                holder.tvStatus.setTextColor(Color.parseColor("#00c853"));
                break;
        }

    }

    @Override
    public int getItemCount() {
        return trans.size();
    }

    public interface OnItemClickListener {      //this is the interface that enables the onclick to work
        void onClick(Transaction trans);
    }

    public class VH extends RecyclerView.ViewHolder {
        TextView tvMsg;
        TextView tvTransID;
        TextView tvStatus;
        TextView tvType;
        TextView tvDate;
        ImageView imgSyncStatus;

        public VH(View v) {
            super(v);
            tvMsg = v.findViewById(R.id.tvMsg);
            tvTransID = v.findViewById(R.id.tvTransID);
            tvStatus = v.findViewById(R.id.tvStatus);
            tvType = v.findViewById(R.id.tvType);
            tvDate = v.findViewById(R.id.tvDate);
            imgSyncStatus = v.findViewById(R.id.imgSync);
            //on click listener for each main transaction
            v.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    listener.onClick(trans.get(getLayoutPosition()));
                }
            });
        }
    }
}
