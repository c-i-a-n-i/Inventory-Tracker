package com.babbangona.sd2;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.ArrayList;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;


/**
 * Created by ciani on 23/04/2018.
 */

public class TransDBHelper extends SQLiteOpenHelper {
    private static final String database = "transactions.db";
    private static final String table = "transactions1";
    private static final String idonline = "idonline";
    private static final String type = "type";
    private static final String msg = "message";
    private static final String product = "product";
    private static final String src = "source";
    private static final String dest = "destination";
    private static final String status = "status";
    private static final String sync = "sync";
    private static final String unit = "unit";
    private static final String quant = "quantity";
    private static final String date = "date";

    SharedPreferences prefs;
    Context context;
    String user;

    public TransDBHelper(Context context) {
        super(context, database, null, 1);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String create = "create table " + table + "(" + "id integer primary key autoincrement not null, "
                + idonline + " text, "
                + type + " text, "
                + msg + " text, "
                + product + " text, "
                + unit + " text, "
                + quant + " text, "
                + src + " text, "
                + dest + " text, "
                + date + " text, "
                + status + " text, "
                + sync + " text);";

        sqLiteDatabase.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists " + table);
        onCreate(sqLiteDatabase);
    }

    public void onAdd(Transaction trans)
    {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(idonline, trans.getIdonline());
        values.put(type, trans.getType());
        values.put(msg, trans.getMsg());
        values.put(product, trans.getProduct());
        values.put(unit, trans.getUnit());
        values.put(quant, trans.getQuant());
        values.put(src, trans.getSrc());
        values.put(dest, trans.getDest());
        values.put(date, trans.getDate());
        values.put(status, trans.getStatus().name());
        values.put(sync, trans.getSync());
        db.insert(table, null, values);
        db.close();
    }

    public ArrayList<Transaction> displayTransactions()
    {
        SQLiteDatabase db = getWritableDatabase();

        String all = "select * from " + table + " order by id";
        Cursor c = db.rawQuery(all,null);
        c.moveToFirst();

        ArrayList<Transaction> trans = new ArrayList<>();

        if(c.getCount() < 1){ return trans;} //makes sure a null cursor is not passed to the add log function below

        do
        {
            trans.add(new Transaction(c.getString(c.getColumnIndex("id")), c.getString(c.getColumnIndex(idonline)), c.getString(c.getColumnIndex(type)), c.getString(c.getColumnIndex(msg)), c.getString(c.getColumnIndex(product)), c.getString(c.getColumnIndex(unit)), c.getString(c.getColumnIndex(quant)), c.getString(c.getColumnIndex(dest)), c.getString(c.getColumnIndex(src)), c.getString(c.getColumnIndex(date)), c.getString(c.getColumnIndex(status)), c.getString(c.getColumnIndex(sync))));
        }while(c.moveToNext());

        c.close();
        db.close();

        return trans;
    }

    public void updateStatus(Transaction trans, String status)
    {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("update " + table + " set status  = '" + status + "' where idonline = '" + trans.getIdonline() + "'");
        Log.i("PASS","Status updated for trans "+ trans.getIdonline());

    }
    /*
   *
   *
   * Functions for transactions sync
   *
   *
   * */
    public void updateSyncStatus(String idonline, String sync){
        String updateQuery = "update " + table + " set sync = '"+ sync +"' where idonline = '" + idonline +"'";
        getReadableDatabase().execSQL(updateQuery);
    }

    public ArrayList<HashMap<String, String>> getAllTrans(){ //actually gets only completed or cancelled sub transactions
        ArrayList<HashMap<String, String>> wordList = new ArrayList<>();
        String selectQuery = "select * from " + table;
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);

        //gets the mik's name to be appended to each log for identification of users
        prefs = context.getSharedPreferences("Preferences", MODE_PRIVATE);
        user = prefs.getString("username"," ");
        cursor.moveToFirst();
        if(cursor.getCount() < 1){ return wordList;}

        do
        {
            HashMap<String, String> map = new HashMap<>();
            map.put("idonline", cursor.getString(cursor.getColumnIndex("idonline")));
            map.put("user", user);
            map.put("message", cursor.getString(cursor.getColumnIndex("message")));
            map.put("status", cursor.getString(cursor.getColumnIndex("status")));
            map.put("date", cursor.getString(cursor.getColumnIndex("date")));
            map.put("sync", cursor.getString(cursor.getColumnIndex("sync")));
            map.put("product", cursor.getString(cursor.getColumnIndex("product")));
            map.put("quant", cursor.getString(cursor.getColumnIndex("quantity")));
            map.put("unit", cursor.getString(cursor.getColumnIndex("unit")));
            map.put("src", cursor.getString(cursor.getColumnIndex("source")));
            map.put("dest", cursor.getString(cursor.getColumnIndex("destination")));
            wordList.add(map);
        }while (cursor.moveToNext());
        cursor.close();

        return wordList;
    }

    public ArrayList<HashMap<String, String>> getAllUnsyncedTrans(){
        ArrayList<HashMap<String, String>> wordList = new ArrayList<>();
        String selectQuery = "select * from " + table + " where sync = 'no'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);

        //gets the mik's name and hub to be appended to each log for identification of users
        prefs = context.getSharedPreferences("Preferences", MODE_PRIVATE);
        user = prefs.getString("username"," ");

        cursor.moveToFirst();
        do
        {
            HashMap<String, String> map = new HashMap<>();
            map.put("idonline", cursor.getString(cursor.getColumnIndex("idonline")));
            map.put("user", user);
            map.put("message", cursor.getString(cursor.getColumnIndex("message")));
            map.put("status", cursor.getString(cursor.getColumnIndex("status")));
            map.put("date", cursor.getString(cursor.getColumnIndex("date")));
            map.put("sync", cursor.getString(cursor.getColumnIndex("sync")));
            map.put("quant", cursor.getString(cursor.getColumnIndex("quantity")));
            map.put("product", cursor.getString(cursor.getColumnIndex("product")));
            map.put("unit", cursor.getString(cursor.getColumnIndex("unit")));
            map.put("src", cursor.getString(cursor.getColumnIndex("source")));
            map.put("dest", cursor.getString(cursor.getColumnIndex("destination")));
            wordList.add(map);
        }while (cursor.moveToNext());
        cursor.close();

        return wordList;
    }

    public int dbSyncCount()
    {
        int count;
        String selectQuery = "select * from " + table + " where sync = 'no'";
        Cursor cursor = getReadableDatabase().rawQuery(selectQuery, null);
        count = cursor.getCount();
        return count;
    }

    public String composeJSONfromSQLite()
    {
        ArrayList<HashMap<String, String>> unsynced = this.getAllUnsyncedTrans();
        Gson gson = new GsonBuilder().create();
        Log.i("SUCCESS","JSON composed "+ gson.toJson(unsynced));
        return gson.toJson(unsynced);
    }
}
