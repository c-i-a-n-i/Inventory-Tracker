package com.babbangona.sd2;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class InternalTransfer extends Fragment {

    TextView tvType;
    TextView tvProduct;
    TextView tvSrc;
    TextView tvDest;
    TextView tvUnit;
    TextView tvQty;
    TextView tvID;
    Button btnInitiate;
    //TODO get actual PC number
    private final String PCnumber = "08090653868";

    SharedPreferences prefs;
    String user;


    public InternalTransfer() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        prefs = getActivity().getSharedPreferences("Preferences", Context.MODE_PRIVATE);
        user = prefs.getString("username", " ");
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_internal_transfer, container, false);

        tvType = v.findViewById(R.id.tvType);
        tvProduct = v.findViewById(R.id.tvProduct);
        tvSrc = v.findViewById(R.id.tvSrc);
        tvDest = v.findViewById(R.id.tvDest);
        tvUnit = v.findViewById(R.id.tvUnit);
        tvQty = v.findViewById(R.id.tvQty);
        tvID = v.findViewById(R.id.tvID);
        btnInitiate = v.findViewById(R.id.btnInitiate);


        tvType.setText(getArguments().getString("type"));
        tvProduct.setText(getArguments().getString("product"));
        tvSrc.setText(getArguments().getString("src"));
        tvDest.setText(getArguments().getString("dest"));
        tvUnit.setText(getArguments().getString("unit"));
        tvQty.setText(getArguments().getString("qty"));
        tvID.setText(getArguments().getString("id"));


        btnInitiate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(tvID.getText().toString().equals("") || tvProduct.getText().toString().equals("") || tvDest.getText().toString().equals("") ||
                        tvUnit.getText().toString().equals("") || tvQty.getText().toString().equals("") || tvSrc.getText().toString().equals(""))
                {
                    Toast.makeText(getActivity(), "Please copy and paste the text message again", Toast.LENGTH_LONG).show();
                    return;
                }

                AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                builder1.setTitle("Begin Shipment");
                builder1.setMessage("Are you sure you want to begin this shipment?");
                builder1.setIcon(android.R.drawable.ic_dialog_alert);
                builder1.setCancelable(true);

                builder1.setPositiveButton(
                        "Yes",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //Initiate transaction and save to database
                                String msg = "Request to move " + tvQty.getText().toString() + " " + tvUnit.getText().toString() + " of " + tvProduct.getText().toString() + " from " +
                                        tvSrc.getText().toString() + " to " + tvDest.getText().toString();
                                Transaction trans = new Transaction(tvID.getText().toString(), tvType.getText().toString(), msg, tvProduct.getText().toString(),
                                        tvUnit.getText().toString(), tvQty.getText().toString(), tvDest.getText().toString(), tvSrc.getText().toString());
                                String sms = tvType.getText().toString() + "," + tvID.getText().toString() + "," + tvSrc.getText().toString() + "," + tvDest.getText().toString() + "," +
                                        tvProduct.getText().toString() + "," + tvQty.getText().toString() + "," + tvUnit.getText().toString() + "," + user;
                                TransDBHelper db = new TransDBHelper(getActivity());
                                db.onAdd(trans);
                                // send sms
                                sendSMS(sms);

                                Intent intent = new Intent(getActivity(), Transactions.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                startActivity(intent);
                            }
                        });

                builder1.setNegativeButton(
                        "No",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

                AlertDialog alert = builder1.create();
                alert.show();
            }
        });
        return v;
    }

    public void sendSMS(String msg)
    {
        if(permissionGranted())
        {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(PCnumber, null, msg, null, null);
            Toast.makeText(getActivity().getApplicationContext(), "SMS sent", Toast.LENGTH_LONG).show();

        }
        else
        {
            ActivityCompat.requestPermissions(getActivity(), new String[] {Manifest.permission.SEND_SMS}, 1);
        }
    }
    //helper function to sendSMS
    public boolean permissionGranted()
    {
        return (ContextCompat.checkSelfPermission(getActivity().getApplicationContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED);
    }


}
