package com.babbangona.sd2;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class Transactions extends AppCompatActivity {

    RecyclerView recyclerView;
    TransAdapter adapter;
    ArrayList<Transaction> tsns;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transactions);

        TransDBHelper db = new TransDBHelper(getApplicationContext());
        tsns = db.displayTransactions();    //gets the list of transactions

        recyclerView = findViewById(R.id.rv);
        adapter = new TransAdapter(getApplicationContext(), tsns, new TransAdapter.OnItemClickListener() {
            @Override
            public void onClick(Transaction trans) {
                switch (trans.getStatus().name()) {
                    case "Collected":
                        confirmedDialog(trans);
                        break;
                    case "Started":
                        unconfirmedDialog(trans);
                        break;
                }
            }
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        recyclerView.setAdapter(adapter);


        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (permissionGranted()) {
                    startActivity(new Intent(getApplicationContext(), NewTransaction.class));
                } else {
                    ActivityCompat.requestPermissions(Transactions.this, new String[]{Manifest.permission.SEND_SMS}, 1);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        TransUpload();
        return true;
    }

    public boolean permissionGranted() {
        return (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED);
    }

    public void unconfirmedDialog(final Transaction tran) {
        String[] options = {"Collect", "Cancel"};
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        // Set the dialog title
        builder.setSingleChoiceItems(options, 0, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int i) {

                switch (i) {
                    case 0:
                        unconfirmedDialog2(tran);
                        break;

                    case 1:
                        cancelDialog(tran);
                        break;
                }
                dialog.cancel();

            }

        })
                .show();

    }


    public void confirmedDialog(final Transaction tran) {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);

        final EditText etToken = new EditText(getApplicationContext());
        final TokenDBhelper tokenDB = new TokenDBhelper(getApplicationContext());
        final TransDBHelper db = new TransDBHelper(getApplicationContext());

        // Set the dialog title
        builder.setTitle("To deliver this shipment, please enter the destination token")
                .setView(etToken)

                // Set the action buttons
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (tokenDB.token2Exists(tran.getIdonline(), etToken.getText().toString())) {
                            db.updateStatus(tran, "Delivered");
                            //All this rubbish is just to restart the activity so that the changes can be reflected
                            finish();
                            startActivity(new Intent(getApplicationContext(), Transactions.class));
                            Toast.makeText(getApplicationContext(), "Shipment delivered!", Toast.LENGTH_LONG).show();
                        } else {
                            Snackbar.make(findViewById(android.R.id.content), "You have entered an invalid token, try again", Snackbar.LENGTH_LONG).show();
                        }

                    }
                })

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // removes the AlertDialog in the screen
                    }
                })
                .show();

    }

    public void unconfirmedDialog2(final Transaction tran) {

        final AlertDialog.Builder builder = new AlertDialog.Builder(this);

        final EditText etToken = new EditText(getApplicationContext());
        final TokenDBhelper tokenDB = new TokenDBhelper(getApplicationContext());
        final TransDBHelper db = new TransDBHelper(getApplicationContext());

        // Set the dialog title
        builder.setTitle("To collect this shipment, please enter the source token")
                .setView(etToken)

                // Set the action buttons
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        if (tokenDB.token1Exists(tran.getIdonline(), etToken.getText().toString())) {
                            db.updateStatus(tran, "Collected");
                            //All this rubbish is just to restart the activity so that the changes can be reflected
                            finish();
                            startActivity(new Intent(getApplicationContext(), Transactions.class));
                            Toast.makeText(getApplicationContext(), "Shipment collected!", Toast.LENGTH_LONG).show();
                        } else {
                            Snackbar.make(findViewById(android.R.id.content), "You have entered an invalid token, try again", Snackbar.LENGTH_LONG).show();
                        }

                    }
                })

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // removes the AlertDialog in the screen
                    }
                })
                .show();

    }

    public void cancelDialog(final Transaction tran) {
        final AlertDialog.Builder builder = new AlertDialog.Builder(this);
        final TransDBHelper db = new TransDBHelper(getApplicationContext());

        builder.setTitle("Cancel Shipment")
                .setMessage("Are you sure you want to cancel this shipment?")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        db.updateStatus(tran, "Cancelled");
                        //All this rubbish is just to restart the activity so that the changes can be reflected
                        finish();
                        startActivity(new Intent(getApplicationContext(), Transactions.class));
                        Toast.makeText(getApplicationContext(), "Shipment cancelled!", Toast.LENGTH_LONG).show();
                    }
                })

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                        // removes the AlertDialog in the screen
                    }
                })
                .show();
    }

    public void TransUpload() {
        final TransDBHelper db = new TransDBHelper(getApplicationContext());
        ArrayList<HashMap<String, String>> logs = db.getAllTrans();
        AsyncHttpClient client = new AsyncHttpClient();
        RequestParams params = new RequestParams();

        if (logs.size() != 0) {
            if (db.dbSyncCount() != 0) {
                params.put("unsyncedJSON", db.composeJSONfromSQLite());
                //http://534df4d8.ngrok.io/bg_inventory/transupdatesd.php
                client.post("http://42fb4fa5.ngrok.io/sd/transupdatesd.php", params, new AsyncHttpResponseHandler() {
                    @Override
                    public void onSuccess(String response) {
                        try {
                            JSONArray arr = new JSONArray(response);
                            for (int i = 0; i < arr.length(); i++) {
                                JSONObject obj = (JSONObject) arr.get(i);
                                //only update the sync column to yes if the status is delivered or cancelled
                                if(obj.get("status").toString().equals("Delivered") || obj.get("status").toString().equals("Cancelled"))
                                {
                                    db.updateSyncStatus(obj.get("idonline").toString(), obj.get("sync").toString());
                                }
                                else {db.updateSyncStatus(obj.get("idonline").toString(), "no");}
                            }
                            Intent intent = new Intent(getApplicationContext(), Transactions.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(intent);
                            Toast.makeText(getApplicationContext(), "DB Sync completed! ", Toast.LENGTH_LONG).show();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onFailure(int statusCode, Throwable error, String content) {
                        if (statusCode == 404) {
                            Toast.makeText(getApplicationContext(), "Requested resource not found", Toast.LENGTH_LONG).show();
                        } else if (statusCode == 500) {
                            Toast.makeText(getApplicationContext(), "Something went wrong at server side", Toast.LENGTH_LONG).show();
                        } else {
                            Toast.makeText(getApplicationContext(), "Unexpected error occurred! [Most common Error: Device might not be connected ]", Toast.LENGTH_LONG).show();
                        }
                    }

                });

            } else {  //Toast.makeText(getApplicationContext(), "SQLite and Remote MySQL DBs are in Sync!", Toast.LENGTH_LONG).show();
            }

        } else { //Toast.makeText(getApplicationContext(), "There are no sub transactions in local db!", Toast.LENGTH_LONG).show();
        }
    }

}
